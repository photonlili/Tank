<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en_AS">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>HNCheckBox</name>
    <message>
        <location filename="../hncheckbox.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNMsgBox</name>
    <message>
        <location filename="../hnmsgbox.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnmsgbox.ui" line="46"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnmsgbox.ui" line="66"/>
        <location filename="../hnmsgbox.ui" line="103"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnmsgbox.ui" line="134"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNProgressBar</name>
    <message>
        <location filename="../hnprogressbar.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTabWidget</name>
    <message>
        <location filename="../hntabwidget.ui" line="14"/>
        <source>TabWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNUpgradeWidget</name>
    <message>
        <location filename="../hnupgradewidget.ui" line="14"/>
        <source>HNUpgradeWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="44"/>
        <location filename="../hnupgradewidget.cpp" line="163"/>
        <source>Please don&apos;t close this computer! Upgrading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="63"/>
        <source>Upgrade:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="79"/>
        <source>Backup:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="86"/>
        <location filename="../hnupgradewidget.ui" line="93"/>
        <source>Waiting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="100"/>
        <source>Wating...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.ui" line="107"/>
        <source>Download:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.cpp" line="172"/>
        <location filename="../hnupgradewidget.cpp" line="187"/>
        <location filename="../hnupgradewidget.cpp" line="200"/>
        <source>Progressing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.cpp" line="180"/>
        <location filename="../hnupgradewidget.cpp" line="195"/>
        <location filename="../hnupgradewidget.cpp" line="210"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.cpp" line="225"/>
        <source>Upgrade success, Restarting... %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="41"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="328"/>
        <source>XX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="335"/>
        <source>Logined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="376"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="183"/>
        <source>Microwave Digestion System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="402"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="407"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="412"/>
        <source>Set up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="417"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="422"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="427"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBackupLocalThread</name>
    <message>
        <location filename="../hnupgradewidget.cpp" line="39"/>
        <source>Progressing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.cpp" line="48"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBackupThread</name>
    <message>
        <location filename="../qsetform.cpp" line="44"/>
        <source>Please Check U Disk!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="53"/>
        <source>Backup success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCDateTime</name>
    <message>
        <location filename="../qcdatetime.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcdatetime.ui" line="20"/>
        <location filename="../qcdatetime.ui" line="34"/>
        <source>↓</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcdatetime.ui" line="41"/>
        <location filename="../qcdatetime.ui" line="51"/>
        <source>↑</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCDialog</name>
    <message>
        <location filename="../qcdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCListView</name>
    <message>
        <location filename="../qclistview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCPushButton</name>
    <message>
        <location filename="../qcpushbutton.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCRadioButton</name>
    <message>
        <location filename="../qcradiobutton.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCSpinBox</name>
    <message>
        <location filename="../qcspinbox.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcspinbox.ui" line="41"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcspinbox.ui" line="64"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCStackedWidget</name>
    <message>
        <location filename="../qcstackedwidget.ui" line="14"/>
        <source>StackedWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCTabWidget</name>
    <message>
        <location filename="../qctabwidget.ui" line="14"/>
        <source>TabWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCTableView</name>
    <message>
        <location filename="../qctableview.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCTreeView</name>
    <message>
        <location filename="../qctreeview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCWidget</name>
    <message>
        <location filename="../qcwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudForm</name>
    <message>
        <location filename="../qcloudform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="33"/>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="85"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="143"/>
        <source>Cloud Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="51"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="78"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudform.ui" line="71"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudLocalModel</name>
    <message>
        <location filename="../qcloudlocalmodel.cpp" line="20"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudlocalmodel.cpp" line="25"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudLocalTreeWidget</name>
    <message>
        <location filename="../qcloudlocaltreewidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudModel</name>
    <message>
        <location filename="../qcloudmodel.cpp" line="46"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qcloudmodel.cpp" line="48"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudTreeView</name>
    <message>
        <location filename="../qcloudtreeview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCloudTreeWidget</name>
    <message>
        <location filename="../qcloudtreewidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDebugWidget</name>
    <message>
        <location filename="../qdebugwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDispelForm</name>
    <message>
        <location filename="../qdispelform.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="66"/>
        <source>Dispel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="139"/>
        <location filename="../qdispelform.ui" line="609"/>
        <source>Library-0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="199"/>
        <location filename="../qdispelform.ui" line="669"/>
        <source>Method-0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="229"/>
        <source>pressing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="386"/>
        <location filename="../qdispelform.ui" line="823"/>
        <source>℃</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="428"/>
        <location filename="../qdispelform.ui" line="830"/>
        <source>Stopped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="557"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="373"/>
        <source>kPa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="315"/>
        <location filename="../qdispelform.ui" line="360"/>
        <location filename="../qdispelform.ui" line="810"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="120"/>
        <location filename="../qdispelform.ui" line="590"/>
        <source>Library:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="180"/>
        <location filename="../qdispelform.ui" line="650"/>
        <source>Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="222"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="347"/>
        <source>Pressure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.ui" line="408"/>
        <location filename="../qdispelform.ui" line="852"/>
        <source>Tempture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.cpp" line="125"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.cpp" line="127"/>
        <source>Extract Lib</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qdispelform.cpp" line="554"/>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEditForm</name>
    <message>
        <location filename="../qeditform.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="165"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="395"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="376"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="408"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="424"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="116"/>
        <source>Vessel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="57"/>
        <location filename="../qeditform.ui" line="106"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="466"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="453"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="213"/>
        <source>Stage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="241"/>
        <source>Tempture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="234"/>
        <source>PressPSI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="227"/>
        <source>TimeRAMP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="220"/>
        <source>Hold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="299"/>
        <source>StageNum:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="126"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="158"/>
        <source>Library:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.ui" line="473"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.cpp" line="162"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.cpp" line="163"/>
        <source>Tempture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qeditform.cpp" line="164"/>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="obsolete">Warning</translation>
    </message>
</context>
<context>
    <name>QExceptionView</name>
    <message>
        <location filename="../qexceptionview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QExceptionWidget</name>
    <message>
        <location filename="../qexceptionwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QFactorySetPassForm</name>
    <message>
        <location filename="../qfactorysetpassform.ui" line="20"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qfactorysetpassform.ui" line="36"/>
        <source>Enter</source>
        <translation type="unfinished">Enter</translation>
    </message>
    <message>
        <location filename="../qfactorysetpassform.ui" line="69"/>
        <source>Factory password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qfactorysetpassform.ui" line="76"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qfactorysetpassform.cpp" line="24"/>
        <source>Password error</source>
        <translation type="unfinished">Password error</translation>
    </message>
</context>
<context>
    <name>QHelpForm</name>
    <message>
        <location filename="../qhelpform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qhelpform.ui" line="36"/>
        <source>Mplayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qhelpform.ui" line="60"/>
        <source>MPlayer Window:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qhelpform.ui" line="74"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qhelpform.ui" line="86"/>
        <source>System Event:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QLibraryForm</name>
    <message>
        <location filename="../qlibraryform.ui" line="17"/>
        <source>Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qlibraryform.ui" line="44"/>
        <source>Library:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qlibraryform.ui" line="133"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qlibraryform.ui" line="146"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qlibraryform.ui" line="165"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qlibraryform.ui" line="172"/>
        <source>Sure</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QLoginDialog</name>
    <message>
        <location filename="../logindialog.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="194"/>
        <source>Enter</source>
        <translation type="unfinished">Enter</translation>
    </message>
    <message>
        <location filename="../logindialog.ui" line="98"/>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="obsolete">Warning</translation>
    </message>
    <message>
        <location filename="../logindialog.cpp" line="55"/>
        <source>Password error</source>
        <translation>Password error</translation>
    </message>
    <message>
        <location filename="../logindialog.cpp" line="62"/>
        <source>User name error</source>
        <translation type="unfinished">User name error</translation>
    </message>
</context>
<context>
    <name>QMPlayerUI</name>
    <message>
        <location filename="../qmplayerui.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmplayerui.ui" line="130"/>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmplayerui.ui" line="85"/>
        <location filename="../qmplayerui.ui" line="99"/>
        <source>00:00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmplayerui.ui" line="137"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmplayerui.ui" line="157"/>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMethodForm</name>
    <message>
        <location filename="../qmethodform.ui" line="17"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodform.ui" line="41"/>
        <source>Select Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodform.cpp" line="79"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodform.cpp" line="82"/>
        <source>Press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodform.cpp" line="85"/>
        <source>RAMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodform.cpp" line="88"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMethodView</name>
    <message>
        <location filename="../qmethodview.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMethodWidget</name>
    <message>
        <location filename="../qmethodwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodwidget.cpp" line="77"/>
        <source>New Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmethodwidget.cpp" line="83"/>
        <source>New Method (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMsgBox</name>
    <message>
        <location filename="../qmsgbox.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmsgbox.cpp" line="18"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QNewUser</name>
    <message>
        <location filename="../qnewuser.ui" line="17"/>
        <source>NewUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="23"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="36"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="43"/>
        <source>Sure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="50"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="63"/>
        <source>Confirm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="70"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qnewuser.ui" line="77"/>
        <source>Authority:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../qtankpublic.cpp" line="42"/>
        <location filename="../qtankpublic.cpp" line="55"/>
        <source>QSQLITE %1 Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QOpenLibrary</name>
    <message>
        <location filename="../qopenlibrary.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPreviewUI</name>
    <message>
        <location filename="../qpreviewui.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qpreviewui.ui" line="20"/>
        <source>Hanon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPreviewWidget</name>
    <message>
        <location filename="../qpreviewwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QProgressWindow</name>
    <message>
        <location filename="../qprogresswindow.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qprogresswindow.ui" line="40"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qprogresswindow.ui" line="20"/>
        <source>Progressing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QReportViewDialog</name>
    <message>
        <location filename="../qreportviewdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.ui" line="20"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.ui" line="27"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="105"/>
        <source>Company:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="107"/>
        <source>User:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="109"/>
        <source>Library:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="111"/>
        <source>Method:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="113"/>
        <source>SerialNo:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="115"/>
        <source>StartTime:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="117"/>
        <source>Plot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="128"/>
        <source>Exception:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="130"/>
        <source>StopReason:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qreportviewdialog.cpp" line="132"/>
        <source>StopTime:%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRunPlot</name>
    <message>
        <location filename="../qrunplot.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qrunplot.ui" line="39"/>
        <source>℃</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qrunplot.ui" line="59"/>
        <source>PSI</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSerialWarning</name>
    <message>
        <location filename="../qserialwarning.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSetForm</name>
    <message>
        <location filename="../qsetform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="57"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="170"/>
        <source>Set time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="411"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="444"/>
        <source>Set language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="359"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="248"/>
        <source>Open userrights:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="455"/>
        <source>Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="489"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="532"/>
        <source>CreateTime:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="525"/>
        <source>Creater:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="539"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="512"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="212"/>
        <source>User rights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="277"/>
        <source>clock wise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="310"/>
        <source>two-way</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="343"/>
        <source>Steering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="473"/>
        <source>User Manager:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="502"/>
        <source>Authority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="552"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="559"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="640"/>
        <source>Optical fiber sensing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="653"/>
        <source>Infrared sensor outer ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="692"/>
        <source>Infrared sensor inner ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="679"/>
        <source>Pressure pickup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="601"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="835"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="766"/>
        <source>Ip address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="705"/>
        <source>Device Check:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="859"/>
        <location filename="../qsetform.ui" line="897"/>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="871"/>
        <location filename="../qsetform.cpp" line="385"/>
        <source>Please insert u disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="884"/>
        <source>this is latest version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="910"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="936"/>
        <source>Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="975"/>
        <source>Serial No.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="949"/>
        <location filename="../qsetform.ui" line="988"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="923"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="962"/>
        <source>Ver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="1093"/>
        <source>Input serial number please!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="1026"/>
        <source>Debug window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="114"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="150"/>
        <source>hh:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="825"/>
        <source>DNS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="776"/>
        <source>Mask:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="799"/>
        <source>Gateway:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="739"/>
        <source>IP configure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="732"/>
        <source>Select network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="756"/>
        <source>Use DHCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="746"/>
        <source>Current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="994"/>
        <source>Factory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="1013"/>
        <source>Calibrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="1055"/>
        <source>Backlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="586"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.ui" line="714"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="obsolete">Warning</translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="268"/>
        <location filename="../qsetform.cpp" line="310"/>
        <source>Name couldn&apos;t be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="281"/>
        <location filename="../qsetform.cpp" line="326"/>
        <source>This user is existed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="287"/>
        <source>Password confirm is not equal to password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="299"/>
        <source>You can&apos;t delete default user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="338"/>
        <source>Save success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="346"/>
        <source>Current:Wired Lan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="351"/>
        <source>Current:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsetform.cpp" line="383"/>
        <source>U disk ready!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password error</source>
        <translation type="obsolete">Password error</translation>
    </message>
</context>
<context>
    <name>QStagePlot</name>
    <message>
        <location filename="../qstageplot.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QStageView</name>
    <message>
        <location filename="../qstageview.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QStageWidget</name>
    <message>
        <location filename="../qstagewidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="31"/>
        <location filename="../qstagewidget.cpp" line="44"/>
        <source>Stage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="32"/>
        <location filename="../qstagewidget.cpp" line="45"/>
        <source>Vessel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="33"/>
        <location filename="../qstagewidget.cpp" line="46"/>
        <source>TimeRAMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="34"/>
        <location filename="../qstagewidget.cpp" line="47"/>
        <source>PressPSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="35"/>
        <location filename="../qstagewidget.cpp" line="48"/>
        <source>Tempture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qstagewidget.cpp" line="36"/>
        <location filename="../qstagewidget.cpp" line="49"/>
        <source>Hold</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSysEventView</name>
    <message>
        <location filename="../qsyseventview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSysEventWidget</name>
    <message>
        <location filename="../qsyseventwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSystemForm</name>
    <message>
        <location filename="../qsystemform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsystemform.ui" line="20"/>
        <source>cpu:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsystemform.ui" line="27"/>
        <source>mem:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTankException</name>
    <message>
        <location filename="../qtankexception.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTankFileDialog</name>
    <message>
        <location filename="../qtankfiledialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTankWindow</name>
    <message>
        <location filename="../qtankwindow.ui" line="20"/>
        <source>StackedWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUpgradeThread</name>
    <message>
        <location filename="../hnupgradewidget.cpp" line="89"/>
        <source>Progressing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hnupgradewidget.cpp" line="98"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserForm</name>
    <message>
        <location filename="../quserform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="33"/>
        <source>User set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="99"/>
        <source>Set theme:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="296"/>
        <source>Set header:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="115"/>
        <source>New pwd:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="171"/>
        <source>Set password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="131"/>
        <source>Confirm pwd:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="164"/>
        <source>Old pwd:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="197"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.ui" line="204"/>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.cpp" line="187"/>
        <source>Old password error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.cpp" line="194"/>
        <source>UnConfirmed new password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserform.cpp" line="201"/>
        <source>Update password OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserLibraryFormatTextDelegate</name>
    <message>
        <location filename="../quserlibraryview.cpp" line="37"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibraryview.cpp" line="39"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibraryview.cpp" line="41"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserLibraryView</name>
    <message>
        <location filename="../quserlibraryview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserLibraryWidget</name>
    <message>
        <location filename="../quserlibrarywidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibrarywidget.cpp" line="71"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibrarywidget.cpp" line="73"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibrarywidget.cpp" line="75"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quserlibrarywidget.cpp" line="97"/>
        <source>New Library</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserSetView</name>
    <message>
        <location filename="../qusersetview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserSetWidget</name>
    <message>
        <location filename="../qusersetwidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qusersetwidget.cpp" line="95"/>
        <source>DefaultLogin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qusersetwidget.cpp" line="96"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qusersetwidget.cpp" line="97"/>
        <source>Authority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWIFIPassForm</name>
    <message>
        <location filename="../qwifipassform.ui" line="14"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qwifipassform.ui" line="33"/>
        <source>WIFI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qwifipassform.ui" line="43"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qwifipassform.ui" line="50"/>
        <source>SSID NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qwifipassform.ui" line="70"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWIFIView</name>
    <message>
        <location filename="../qwifiview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWIFIWidget</name>
    <message>
        <location filename="../qwifiwidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qwifiwidget.cpp" line="51"/>
        <source>Password error</source>
        <translation type="unfinished">Password error</translation>
    </message>
</context>
<context>
    <name>frmInput</name>
    <message>
        <location filename="../frminput.ui" line="20"/>
        <source>中文输入法面板</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="325"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="350"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="605"/>
        <location filename="../frminput.ui" line="1689"/>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="951"/>
        <source>t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1593"/>
        <source>|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1476"/>
        <source>(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="589"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1348"/>
        <source>!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1199"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1247"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="525"/>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="818"/>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="706"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1231"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1412"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1151"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="509"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="834"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1015"/>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="754"/>
        <source>g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="786"/>
        <source>j</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="738"/>
        <source>f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1657"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="621"/>
        <location filename="../frminput.ui" line="1705"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="983"/>
        <source>u</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1364"/>
        <source>@</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1183"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1561"/>
        <source>\</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="557"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1263"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1167"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1673"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1609"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="541"/>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="919"/>
        <source>e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1444"/>
        <source>&amp;&amp;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1784"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1791"/>
        <source>英文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1798"/>
        <source>123</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="999"/>
        <source>i</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="770"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1380"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1215"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="690"/>
        <source>a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="573"/>
        <source>n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1428"/>
        <source>^</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="722"/>
        <source>d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1396"/>
        <source>$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="493"/>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1119"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="802"/>
        <source>k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1135"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="903"/>
        <source>w</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="935"/>
        <source>r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1460"/>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="887"/>
        <source>q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="967"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1492"/>
        <source>)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1031"/>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1625"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="637"/>
        <location filename="../frminput.ui" line="1721"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1577"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../frminput.ui" line="1641"/>
        <source>&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
