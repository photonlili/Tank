#include "../../src/serialport/qt4support/include/QtCore/qlockfile.h"
