#include "../../../../../src/serialport/qserialportinfo_p.h"
