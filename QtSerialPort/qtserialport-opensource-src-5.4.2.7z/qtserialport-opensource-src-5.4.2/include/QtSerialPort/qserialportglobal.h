#include "../../src/serialport/qserialportglobal.h"
