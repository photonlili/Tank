#include "../../src/serialport/qserialportinfo.h"
