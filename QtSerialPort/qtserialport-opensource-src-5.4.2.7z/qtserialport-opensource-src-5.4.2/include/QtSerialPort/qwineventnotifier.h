#include "../../src/serialport/qt4support/include/QtCore/qwineventnotifier.h"
