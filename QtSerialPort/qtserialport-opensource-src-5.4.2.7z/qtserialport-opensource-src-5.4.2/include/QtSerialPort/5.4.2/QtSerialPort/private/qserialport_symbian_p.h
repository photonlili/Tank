#include "../../../../../src/serialport/qserialport_symbian_p.h"
