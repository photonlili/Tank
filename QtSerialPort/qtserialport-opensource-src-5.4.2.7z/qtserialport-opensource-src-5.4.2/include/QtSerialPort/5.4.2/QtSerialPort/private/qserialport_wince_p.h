#include "../../../../../src/serialport/qserialport_wince_p.h"
