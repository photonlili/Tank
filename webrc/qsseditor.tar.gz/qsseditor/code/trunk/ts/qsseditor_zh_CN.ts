<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>About</name>
    <message>
        <location filename="../about.ui" line="68"/>
        <source>OK</source>
        <translation>好的</translation>
    </message>
    <message>
        <location filename="../about.ui" line="103"/>
        <source>QSS Editor is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.</source>
        <extracomment>See https://www.gnu.org/licenses/gpl-2.0.txt . &quot;THT&quot; is the name of the application</extracomment>
        <translation>QSS 编辑器的发布是希望它能对用户有所帮助，但它没有任何担保；也没有适销性或针对特定用途的的默示性担保。</translation>
    </message>
    <message>
        <location filename="../about.ui" line="122"/>
        <source>QSS Editor is a tool to edit and preview Qt style sheets</source>
        <extracomment>&quot;THT&quot; is the name of the application. The URL to visit will be added in runtime. Ticker is a short company name, see http://www.investopedia.com/terms/t/tickersymbol.asp . The common practice is to borrow &quot;ticker&quot; from English and incorporate into your language (see http://en.wikipedia.org/wiki/Loanword)</extracomment>
        <translation>QSS 编辑器是一个编辑和预览 Qt 样式表的工具</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="37"/>
        <source>Dmitry Baryshev</source>
        <translation>Dmitry Baryshev</translation>
    </message>
</context>
<context>
    <name>Options</name>
    <message>
        <location filename="../options.ui" line="14"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../options.ui" line="22"/>
        <source>Language:</source>
        <translation>语言:</translation>
    </message>
    <message>
        <location filename="../options.ui" line="57"/>
        <source>Open last style at startup</source>
        <translation>启动时打开最后一个样式</translation>
    </message>
    <message>
        <location filename="../options.ui" line="66"/>
        <source>Preview delay:</source>
        <translation>预览延迟:</translation>
    </message>
    <message>
        <location filename="../options.ui" line="73"/>
        <source>ms</source>
        <translation>毫秒</translation>
    </message>
    <message>
        <location filename="../options.ui" line="120"/>
        <source>Need restart</source>
        <translation>需要重新启动程序</translation>
    </message>
    <message>
        <location filename="../options.cpp" line="32"/>
        <source>System</source>
        <translation>系统</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../project.cpp" line="38"/>
        <source>File name is empty</source>
        <translation>文件名为空</translation>
    </message>
    <message>
        <location filename="../project.cpp" line="130"/>
        <source>The data stream has read past the end of the data</source>
        <translation>数据流已读取到数据末尾</translation>
    </message>
    <message>
        <location filename="../project.cpp" line="133"/>
        <source>The data stream has read corrupt data</source>
        <translation>数据流读取到损坏的数据</translation>
    </message>
    <message>
        <location filename="../project.cpp" line="137"/>
        <source>The data stream cannot write to the underlying device</source>
        <translation>数据流无法写入到该基础设备</translation>
    </message>
    <message>
        <location filename="../project.cpp" line="140"/>
        <source>Unknown error</source>
        <translation>未知错误</translation>
    </message>
    <message>
        <location filename="../tools.h" line="39"/>
        <source>About QSS Editor</source>
        <translation>关于 QSS 编辑器</translation>
    </message>
</context>
<context>
    <name>QsciCommand</name>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="59"/>
        <source>Move down one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="69"/>
        <source>Extend selection down one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="79"/>
        <source>Extend rectangular selection down one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="86"/>
        <source>Scroll view down one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="96"/>
        <source>Move up one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="106"/>
        <source>Extend selection up one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="116"/>
        <source>Extend rectangular selection up one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="123"/>
        <source>Scroll view up one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="133"/>
        <source>Scroll to start of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="143"/>
        <source>Scroll to end of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="153"/>
        <source>Scroll vertically to centre current line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="160"/>
        <source>Move down one paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="166"/>
        <source>Extend selection down one paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="173"/>
        <source>Move up one paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="179"/>
        <source>Extend selection up one paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="190"/>
        <source>Move left one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="200"/>
        <source>Extend selection left one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="211"/>
        <source>Extend rectangular selection left one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="222"/>
        <source>Move right one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="232"/>
        <source>Extend selection right one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="243"/>
        <source>Extend rectangular selection right one character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="254"/>
        <source>Move left one word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="264"/>
        <source>Extend selection left one word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="274"/>
        <source>Move right one word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="280"/>
        <source>Extend selection right one word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="286"/>
        <source>Move to end of previous word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="292"/>
        <source>Extend selection to end of previous word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="303"/>
        <source>Move to end of next word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="313"/>
        <source>Extend selection to end of next word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="320"/>
        <source>Move left one word part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="326"/>
        <source>Extend selection left one word part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="333"/>
        <source>Move right one word part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="339"/>
        <source>Extend selection right one word part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="350"/>
        <source>Move to start of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="360"/>
        <source>Extend selection to start of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="371"/>
        <source>Extend rectangular selection to start of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="382"/>
        <source>Move to start of display line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="392"/>
        <source>Extend selection to start of display line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="399"/>
        <source>Move to start of display or document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="406"/>
        <source>Extend selection to start of display or document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="417"/>
        <source>Move to first visible character in document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="428"/>
        <source>Extend selection to first visible character in document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="439"/>
        <source>Extend rectangular selection to first visible character in document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="446"/>
        <source>Move to first visible character of display in document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="453"/>
        <source>Extend selection to first visible character in display or document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="464"/>
        <source>Move to end of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="474"/>
        <source>Extend selection to end of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="485"/>
        <source>Extend rectangular selection to end of document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="496"/>
        <source>Move to end of display line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="506"/>
        <source>Extend selection to end of display line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="513"/>
        <source>Move to end of display or document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="520"/>
        <source>Extend selection to end of display or document line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="531"/>
        <source>Move to start of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="541"/>
        <source>Extend selection to start of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="552"/>
        <source>Move to end of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="562"/>
        <source>Extend selection to end of document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="569"/>
        <source>Move up one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="575"/>
        <source>Extend selection up one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="581"/>
        <source>Extend rectangular selection up one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="592"/>
        <source>Move down one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="602"/>
        <source>Extend selection down one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="612"/>
        <source>Extend rectangular selection down one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="619"/>
        <source>Stuttered move up one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="625"/>
        <source>Stuttered extend selection up one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="632"/>
        <source>Stuttered move down one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="638"/>
        <source>Stuttered extend selection down one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="649"/>
        <source>Delete current character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="659"/>
        <source>Delete previous character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="665"/>
        <source>Delete previous character if not at start of line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="672"/>
        <source>Delete word to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="678"/>
        <source>Delete word to right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="688"/>
        <source>Delete right to end of next word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="695"/>
        <source>Delete line to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="705"/>
        <source>Delete line to right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="711"/>
        <source>Delete current line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="717"/>
        <source>Cut current line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="723"/>
        <source>Copy current line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="729"/>
        <source>Transpose current and previous lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="736"/>
        <source>Duplicate the current line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="742"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="748"/>
        <source>Move selected lines up one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="754"/>
        <source>Move selected lines down one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="761"/>
        <source>Duplicate selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="767"/>
        <source>Convert selection to lower case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="773"/>
        <source>Convert selection to upper case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="779"/>
        <source>Cut selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="785"/>
        <source>Copy selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="791"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="797"/>
        <source>Toggle insert/overtype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="803"/>
        <source>Insert newline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="809"/>
        <source>Formfeed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="815"/>
        <source>Indent one level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="821"/>
        <source>De-indent one level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="827"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="833"/>
        <source>Undo last command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="843"/>
        <source>Redo last command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="849"/>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscicommandset.cpp" line="855"/>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QsciLexerCSS</name>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="232"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="235"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="238"/>
        <source>Class selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="241"/>
        <source>Pseudo-class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="244"/>
        <source>Unknown pseudo-class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="247"/>
        <source>Operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="250"/>
        <source>CSS1 property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="253"/>
        <source>Unknown property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="256"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="259"/>
        <source>ID selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="262"/>
        <source>Important</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="265"/>
        <source>@-rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="268"/>
        <source>Double-quoted string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="271"/>
        <source>Single-quoted string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="274"/>
        <source>CSS2 property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="277"/>
        <source>Attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="280"/>
        <source>CSS3 property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="283"/>
        <source>Pseudo-element</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="286"/>
        <source>Extended CSS property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="289"/>
        <source>Extended pseudo-class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="292"/>
        <source>Extended pseudo-element</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="295"/>
        <source>Media rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qscilexercss.cpp" line="298"/>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QsciScintilla</name>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4328"/>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4332"/>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4338"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4343"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4349"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4353"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qscintilla/Qt4Qt5/qsciscintilla.cpp" line="4360"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QssEditor</name>
    <message>
        <location filename="../qsseditor.ui" line="29"/>
        <location filename="../qsseditor.cpp" line="407"/>
        <source>Open style</source>
        <translation>打开样式</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="39"/>
        <source>Save style</source>
        <translation>保存样式</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="46"/>
        <location filename="../qsseditor.cpp" line="429"/>
        <source>Save style as</source>
        <translation>另存样式为</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="72"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="92"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="99"/>
        <source>Redo</source>
        <translation>恢复</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="119"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../qsseditor.ui" line="172"/>
        <source>Preview style</source>
        <translation>预览样式</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="202"/>
        <source>Cannot open style:</source>
        <translation>不能打开样式:</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="230"/>
        <source>Cannot save style:</source>
        <translation>不能保存样式:</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="249"/>
        <source>No error</source>
        <translation>没有错误</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="252"/>
        <source>File access error</source>
        <translation>文件读取错误</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="255"/>
        <source>Malformed file</source>
        <translation>文件格式错误</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="258"/>
        <source>Unknown error</source>
        <translation>未知错误</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="265"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="266"/>
        <source>This will discard all the unsaved changes</source>
        <translation>这将丢弃所有未保存的更改</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="279"/>
        <source>Cannot open style. The file doesn&apos;t exist or not readable</source>
        <translation>无法打开样式。该文件不存在或无法读取</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="285"/>
        <source>Cannot change directory</source>
        <translation>不能更改目录</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="299"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="375"/>
        <source>QSS Editor</source>
        <translation>QSS 编辑器</translation>
    </message>
    <message>
        <location filename="../qsseditor.cpp" line="407"/>
        <location filename="../qsseditor.cpp" line="429"/>
        <source>Qt Style Sheets (*.qss)</source>
        <translation>Qt 样式表 (*.qss)</translation>
    </message>
</context>
<context>
    <name>SearchAndReplace</name>
    <message>
        <location filename="../searchandreplace.ui" line="14"/>
        <source>Find and Replace</source>
        <translation>查找和替换</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="20"/>
        <source>Find:</source>
        <translation>查找内容:</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="27"/>
        <source>Replace with:</source>
        <translation>替换为:</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="34"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="40"/>
        <source>Case sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="47"/>
        <source>Whole words</source>
        <translation>全字匹配</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="54"/>
        <source>Regular expression</source>
        <translation>正则表达式</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="66"/>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="76"/>
        <source>Replace&amp;&amp;Next</source>
        <extracomment>The sign &quot;&amp;&amp;&quot; means &quot;&amp;&quot; (&quot;AND&quot;). So the button name means &quot;Replace the found text and search again&quot;</extracomment>
        <translation>替换并查找下一个</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="86"/>
        <source>Replace All</source>
        <translation>全部替换</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="93"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="117"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="123"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../searchandreplace.ui" line="130"/>
        <source>Down</source>
        <translation>向下</translation>
    </message>
</context>
</TS>
